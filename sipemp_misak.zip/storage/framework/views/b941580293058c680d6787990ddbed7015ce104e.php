<style>
    table{
        text-align: center;
    }
    table>head>tr:first-child{
        font-size: 50px;
    }
</style>
<table>
    <thead>
        <tr >
            <td colspan="4" rowspan="3">
                <img src="<?php echo e(public_path('images/logo_v1.jpg')); ?>" alt="logo" width="300px">
            </td>
            <td colspan="13" rowspan="3">FORMATO LISTADO CENSAL ANEXO </td>
            <td colspan="2">Código:</td>
        </tr>
        <tr>
            <td colspan="2">Versión:</td>
        </tr>
        <tr>
            <td colspan="2">Vigente Desde: </td>
        </tr>
        <tr>
            <th>#</th>
            <th>VIGENCIA </th>
            <th>RESGUARDO INDIGENA</th>
            <th>COMUNIDAD INDIGENA</th>
            <th>FAMILIA</th>
            <th>TIPO IDENTIFICACION</th>
            <th>NUMERO DOCUMENTO</th>
            <th>NOMBRES</th>
            <th>APELLIDOS</th>
            <th>FECHA NACIMIENTO</th>
            <th>PARENTESCO</th>
            <th>SEXO</th>
            <th>ESTADO CIVIL</th>
            <th>PROFESION</th>
            <th>ESCOLARIDAD</th>
            <th>INTEGRANTES</th>
            <th>DIRECCION</th>
            <th>TELEFONO</th>
            <th>USUARIO</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td> <?php echo e($key+1); ?></td>
                <td><?php echo e($persona->vigencia); ?></td>
                <td><?php echo e($persona->resguardo); ?></td>
                <td><?php echo e($persona->comunidad_indigena); ?></td>
                <td><?php echo e($persona->familia); ?></td>
                <td><?php echo e($persona->tipo_identificacion); ?></td>
                <td><?php echo e($persona->docomento_persona); ?></td>
                <td><?php echo e($persona->nombres); ?></td>
                <td><?php echo e($persona->apellidos); ?></td>
                <td><?php echo e($persona->fecha_nacimiento); ?></td>
                <td><?php echo e($persona->parentesco); ?></td>
                <td><?php echo e($persona->sexo); ?></td>
                <td><?php echo e($persona->estado_civil); ?></td>
                <td><?php echo e($persona->profesion); ?></td>
                <td><?php echo e($persona->escolaridad); ?></td>
                <td><?php echo e($persona->integrantes); ?></td>
                <td><?php echo e($persona->vereda); ?>-Sector-<?php echo e($persona->sector); ?>

                </td>
                <td><?php echo e($persona->telefono); ?></td>
                <td>CABILDO DE GUAMBIA</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\sipemp_misak\resources\views/Exports_Excel/reporte_genera_censo_excel.blade.php ENDPATH**/ ?>