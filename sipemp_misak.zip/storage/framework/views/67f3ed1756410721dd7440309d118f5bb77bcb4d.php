<?php $__env->startSection('content'); ?>

      <!--\\\\\\\ contentpanel start\\\\\\-->
      <div class="pull-left breadcrumb_admin clear_both">
        <div class="pull-left page_title theme_color">
          <h1>NOVEDADES</h1>
          <h2 class="">Menu</h2>
        </div>
        <div class="pull-right">
          <ol class="breadcrumb">
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Novedades</a></li>
            <li class="active">Menu</li>
          </ol>
        </div>
      </div>	

    
<section style="padding: 10rem 0;">

<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
            <div class="zona-consulta col-sm-6 text-center col-lg-4" ng-class="(origenKiosco)? 'col-lg-6' : 'col-lg-4'">
                <div class="btns-consulta">
                    <div class="">
                        <button type="button" class="circulo-consulta" onclick="location.href='<?php echo e(url('Menu-Usuarios')); ?>'" > 
                            <img src="modules/content/img/icon_lugar.png" class="icon_consulta">  
                            <div class="titulo-consulta textoConsulta">
                            Usuarios del sistema SIPEMP
                                <div class="clearfix"></div>
                            </div>
                            <div class="texto-consulta textoConsulta">
                            ingresar usuarios en el sistema de información poblacional SIPEMP
                            </div>
                        </button>
                    </div>
                    
                </div>
            </div>
            <div class="zona-consulta col-sm-6 text-center col-lg-4" >
                <div class="btns-consulta">
                    <div class="">
                        <button type="button" class="circulo-consulta" onclick="location.href='<?php echo e(url('Validacion')); ?>'">
                            <img src="modules/content/img/icon_jurado.png" class="icon_consulta">
                            <div class="titulo-consulta text-center textoConsulta">
                            Validacion de retiro del censo poblacional  
                                <div class="clearfix"></div>
                            </div>
                            <div class="texto-consulta textoConsulta">
                            Varidar retiro de censo Poblacional Misak SIPEMP  
                            </div>
                        </button>
                    </div>
                </div>
         </div>
    </div>
</div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan Marulanda\Desktop\sipemp-version_1\resources\views//administrador/nemuAdministrador.blade.php ENDPATH**/ ?>