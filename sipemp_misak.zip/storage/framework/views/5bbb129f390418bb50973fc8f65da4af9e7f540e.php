<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="css/estilos_pie_pagina.css">
<!--\\\\\\\ contentpanel start\\\\\\-->
<div class="pull-left breadcrumb_admin clear_both">
    <div class="pull-left page_title theme_color">
        <h1>Reporte</h1>
        <h2 class="">Reporte por Vigencia</h2>
    </div>
    <div class="pull-right">
        <ol class="breadcrumb">
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Reporte</a></li>
            <li class="active">Reporte por Vigencia</li>
        </ol>
    </div>
</div>


<br>
<br>
<br>
<div class="color_informacion_modulo " style="margin-top: 15px;">
    <span class="color_infor  ">Usted se encuentra en: &nbsp;&nbsp;<font color="#060505"> Sistema de Informacion
            Poblacional Misak -SIPEMP &gt; <font color="#060505">Reportes </font> &gt; <font color="#060505">Reporte por
                Vigencia formato Ministerios</font> </span>
</div>

<div class="col-lg-12">

    <section class="panel default blue_title h2">
        <div class="panel-heading"><span class="semi-bold"></span> </div>
        <div class="ContenedorFormularioCenso">
            <div class="panel-body">
                <ul class="nav nav-tabs" id="myTab">
                    <li class="active"><a data-toggle="tab" href="#Tab1">CENSO GENERAL POR VIGENCIA</a></li>


                </ul>

                <div class="tab-content" id="myTabContent">
                    <div id="Tab1" class="tab-pane fade in active" style="margin: 0;">
                        <!----TAP 1 ------>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="content-header">Censo General</h3>

                                    <div class="table-responsive">
                                        <?php if(isset($personas)): ?>
                                            <h4>La Información del censo poblacional del Resguardo de Guambia
                                                vigencia son:</h4>
                                                <a href="/Censo_general/download" target="_blank" class="btn btn-defaul">Descargar</a>
                                                
                                            <table class="table table-bordered table-striped">
                                                <thead>

                                                    <tr>
                                                        <th>#</th>
                                                        <th>VIGENCIA </th>
                                                        <th>RESGUARDO INDIGENA</th>
                                                        <th>COMUNIDAD INDIGENA</th>
                                                        <th>FAMILIA</th>
                                                        <th>TIPO IDENTIFICACION</th>
                                                        <th>NUMERO DOCUMENTO</th>
                                                        <th>NOMBRES</th>
                                                        <th>APELLIDOS</th>
                                                        <th>FECHA NACIMIENTO</th>
                                                        <th>PARENTESCO</th>
                                                        <th>SEXO</th>
                                                        <th>ESTADO CIVIL</th>
                                                        <th>PROFESION</th>
                                                        <th>ESCOLARIDAD</th>
                                                        <th>INTEGRANTES</th>
                                                        <th>DIRECCION</th>
                                                        <th>TELEFONO</th>
                                                        <th>USUARIO</th>

                                                    </tr>


                                                </thead>
                                                <tbody>

                                                    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>

                                                            <td> <?php echo e($key+1); ?></td>
                                                            <td><?php echo e($persona->vigencia); ?></td>
                                                            <td><?php echo e($persona->resguardo); ?></td>
                                                            <td><?php echo e($persona->comunidad_indigena); ?></td>
                                                            <td><?php echo e($persona->familia); ?></td>
                                                            <td><?php echo e($persona->tipo_identificacion); ?></td>
                                                            <td><?php echo e($persona->docomento_persona); ?></td>
                                                            <td><?php echo e($persona->nombres); ?></td>
                                                            <td><?php echo e($persona->apellidos); ?></td>
                                                            <td><?php echo e($persona->fecha_nacimiento); ?></td>
                                                            <td><?php echo e($persona->parentesco); ?></td>
                                                            <td><?php echo e($persona->sexo); ?></td>
                                                            <td><?php echo e($persona->estado_civil); ?></td>
                                                            <td><?php echo e($persona->profesion); ?></td>
                                                            <td><?php echo e($persona->escolaridad); ?></td>
                                                            <td><?php echo e($persona->integrantes); ?></td>
                                                            <td><?php echo e($persona->vereda); ?>-Sector-<?php echo e($persona->sector); ?>

                                                            </td>
                                                            <td><?php echo e($persona->telefono); ?></td>
                                                            <td>CABILDO DE GUAMBIA</td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        <?php elseif(isset($message)): ?>
                                            <h3> <?php echo e($message); ?></h3>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!--/porlets-content-->
                            </div>
                        </div>
                        <!--/block-web-->
                    </div>
                    <!--/col-md-12-->
                </div>
                <!--/row-->
            </div>
            <!--FIN --TAP 1 ------>


        </div>
</div>
</section>
</div>
</div>
<br>
<br>
<br>
<br>
<br>


<!-- script de la librerias chart para generar reportes  -->
<script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('vendors/Chart.js/dist/Chart.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('vendors/build/js/custom.min.js')); ?>" defer></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan Marulanda\Desktop\sipemp-version_1\resources\views/reportes/censo_general_vigencia.blade.php ENDPATH**/ ?>