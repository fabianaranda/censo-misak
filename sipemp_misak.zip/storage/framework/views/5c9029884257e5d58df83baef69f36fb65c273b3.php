<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Idiomas', 'Cantidad'],
          
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pastels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          [ '<?php echo e($pastels->nombre); ?>','<?php echo e($pastels->stock); ?>'] 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);
        

        var options = {
          title: 'My Daily Activities',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\sipemp_misak\resources\views/reportes/reporte_educacion_propia.blade.php ENDPATH**/ ?>