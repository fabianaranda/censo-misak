<!DOCTYPE html PUBLIC  "">

<html xmlns=">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



<link href="./css/bootstrap-theme.css" rel="Stylesheet" type="text/css">
<link href="./css/bootstrap_oferente.css" rel="Stylesheet" type="text/css">


<title>

</title></head>
<body>
    <form name="form1" method="post"  id="form1">

       <br>
       <br>
       <br>
       <br>

        <div class="datos_user col-md-3 col-sm-12 col-xs-12">
      

            <!--
                <p style="font-family: Arial;font-size:1.35em;color:#606060;font-weight:bold;margin-top:10px;"><strong>Proceso del SIPEMP</strong></p>
                
                <div class="pull-right">
                    1%
                </div>
                -->
                <div class="clearfix"></div>
                <div class=" progress">

                   -
                </div>
               <ul class="list-group lista-cuenta">
                
				 <li id="DivDescargaHV" class="list-group-item">
                    <i class="icon-download-alt"></i>
                </li>
                
             

               </ul>
                <div class="clearfix"></div>
            
             <div class="clearfix"></div>
        </div>
    </form>

</body>

</html><?php /**PATH C:\Users\Juan Marulanda\Desktop\sipemp-version_1\resources\views/menu_lateral/menu_lateral_informacion.blade.php ENDPATH**/ ?>