<?php $__env->startSection('content'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="/js/sweetalert2@9.js"></script>

<link rel="stylesheet" href="css/estilos_pie_pagina.css">

<!-- Main CSS -->
<link href="css/admin.css" rel="stylesheet" type="text/css" />

<!-- Sub Nav -->
<div class="pull-left breadcrumb_admin clear_both">
    <div class="pull-left page_title theme_color">
        <h1>CENSO POBLACIONAL </h1>
        <h2 class="">Hogar </h2>
    </div>
    <div class="pull-right">
        <ol class="breadcrumb">
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Ceonso Poblacional</a></li>
            
        </ol>
    </div>
</div>

<div class="container">
    <!-- Progreso del formulario -->
    <div class="col-md-3 col-sm-4 col-xs-12 ">

        <iframe frameborder="0" width="100%" scrolling="no" height="245" src="./menu-lateral">

        </iframe>
    </div>

    
    <div class="col-md-9 ">
        <div class="ContenedorFormularioCenso">
            <div class="titulo_informacion">

                
                <table>
                    <tbody>
                        <tr>
                            <td style="width:3px;"></td>
                            <td title="Censo vivienda de familia Misak">
                                <table class="active">
                                    <tbody>
                                        <tr>
                                            <td><b href="">VIVIENDA MISAK</b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>

                            <td style="width:3px;"></td>
                            <td title="Censo del Hogar Misak  ">
                                <table class="estatic">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b href="">HOGAR MISAK </b>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                            </td>

                            <td style="width:3px;"></td>
                            <td title="Miembros de la familia   Misak ">
                                <table class="active">
                                    <tbody>
                                        <tr>
                                            <td><b href="">FAMILIA MISAK</b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>

                            <td title="Información de la persona que viven dentro de la familia ">
                                <table class="active">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b href="">PERSONAS </b>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                            </td>

                            <td style="width:3px;"></td>
                            <td title="Información de la persona que viven dentro de la familia ">
                                <table class="active">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b href="">INFORMACIÓN PERSONA </b>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                            </td>

                            <td style="width:3px;"></td>
                            <td title="Nivel educativo  que tiene  la persona que vive en la familia">
                                <table class="active">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b href="">NIVEL EDUCATIVO </b>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div class="color_infor noPrint" style="margin-top: 15px;">
                    <span class="color_infor  noPrint">Usted se encuentra en:&nbsp;&nbsp;Censo poblacional Misak SIPEMP</span>
                </div>
            </div>

            <div class="well resume-module module-jobs">
                <h2 class="module-title">
                    Vivienda Misak
                </h2>
                <div class="js-box-laboral-experience" id="experiencia-laboral">
                    <h3 class="h4">Si la familia que va realizar el censo población tiene vivienda Propia, ingresar en
                        este módulo censo vivienda Misak. </h3>
                    <div class="module-collapsible collapse in" aria-expanded="true">
                        <div class="module-summary-wrapper laboral-experience">
                            <hr style="border: 1px solid #e0e0e0;">
                            <a class="btn btn-primary" href="<?php echo e(url('Vivienda')); ?>">Ingresar</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="well resume-module module-jobs">
                <h2 class="module-title">
                    Hogar Misak
                </h2>
                <div class="js-box-laboral-experience" id="experiencia-laboral">
                    <h3 class="h4">Si la Familia vive dentro de la vivienda de algún familiar, (Padre, tío) ingresar
                        en este módulo Hogar Misak. </h3>
                    <div class="module-collapsible collapse in" aria-expanded="true">
                        <div class="module-summary-wrapper laboral-experience">
                            <hr style="border: 1px solid #e0e0e0;">
                            <a class="btn btn-primary" href="<?php echo e(url('Vivienda')); ?>">Ingresar</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>



<script type="text/javascript">
$('#departamento').change(function() {
    var departamentoID = $(this).val();
    if (departamentoID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get-municipio-list')); ?>?codigo_departamento=" + departamentoID,
            success: function(res) {
                if (res) {
                    $("#municipio").empty();
                    $("#municipio").append('<option>Seleccione Municipio</option>');
                    $.each(res, function(key, value) {
                        $("#municipio").append('<option value="' + key + '">' + value +
                            '</option>');
                    });

                } else {
                    $("#municipio").empty();
                }
            }
        });
    } else {
        $("#municipio").empty();
        $("#resguardo").empty();
    }
});


$('#municipio').on('change', function() {
    var municipioID = $(this).val();
    if (municipioID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get-resguardo-list')); ?>?codigo_municipio=" + municipioID,
            success: function(res) {
                if (res) {
                    $("#resguardo").empty();
                    $("#resguardo").append('<option>Seleccione Resguardo </option>');
                    $.each(res, function(key, value) {
                        $("#resguardo").append('<option value="' + key + '">' + value +
                            '</option>');
                    });

                } else {
                    $("#resguardo").empty();
                }
            }
        });
    } else {
        $("#resguardo").empty();
        $("#zona").empty();
    }

});


$('#resguardo').on('change', function() {
    var resguardoID = $(this).val();
    if (resguardoID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get-zona-list')); ?>?codigo_resguardo=" + resguardoID,
            success: function(res) {
                if (res) {
                    $("#zona").empty();
                    $("#zona").append('<option>Seleccione Zona</option>');
                    $.each(res, function(key, value) {
                        $("#zona").append('<option value="' + key + '">' + value +
                            '</option>');
                    });

                } else {
                    $("#zona").empty();
                }
            }
        });
    } else {
        $("#zona").empty();
        $("#vereda").empty();
    }

});

$('#zona').on('change', function() {
    var zonaID = $(this).val();
    if (zonaID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get-vereda-list')); ?>?codigo_zona=" + zonaID,
            success: function(res) {
                if (res) {
                    $("#vereda").empty();
                    $("#vereda").append('<option>Seleccione Vereda</option>');
                    $.each(res, function(key, value) {
                        $("#vereda").append('<option value="' + key + '">' + value +
                            '</option>');
                    });

                } else {
                    $("#vereda").empty();
                }
            }
        });
    } else {
        $("#vereda").empty();
        $("#sector").empty();
    }

});

$('#vereda').on('change', function() {
    var veredaID = $(this).val();
    if (veredaID) {
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get-sector-list')); ?>?codigo_vereda=" + veredaID,
            success: function(res) {
                if (res) {
                    $("#sector").empty();
                    $("#sector").append('<option>Seleccione Sector</option>');
                    $.each(res, function(key, value) {
                        $("#sector").append('<option value="' + key + '">' + value +
                            '</option>');
                    });

                } else {
                    $("#sector").empty();
                }
            }
        });
    } else {
        $("#sector").empty();

    }

});
// buscar codigo vivienda
$(function() {
    $('#buscar').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            data: $(this).serialize(),
            type: $(this).attr('method'),
            success: function(data) {
                console.log(data);
                Search();
            }
        })
    })
})
</script>

<script>
function Search() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("q");
    filter = input.value.toUpperCase();
    table = document.getElementById("refresh");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}
</script>



<script type="text/javascript">
//--Modificación para disminuir lentitud de la página y disminuir las peticiones al servidor.
//PARA QUE APARESCAN LOS OBCIONES  CUANDO SELECCIONE  NO TENGO HIJOS ESTUDIANDO  EN LAS INSTITUICONES EDUCATIVAS DEL RESGUARDO
function showNoEstudiaResguardo() {
    var e = document.getElementById("ddNoEstudiaResguardo");
    var strUser = e.options[e.selectedIndex].value;
    if (strUser == 1) {
        //input ¿Por qué no le gusta que sus hijos estudien en las instituciones educativas del resguardo de Guambia?
        $('#NoGustaQueEstudienGuambia').show();
        $('#NoGustaQueEstudienGuambia').css('visibility', 'visible');
        $('#ddNoEstudiaResguardoEscuela').css('display', 'block');

        //input ¿El problema de la deserción escolar    en nuestro pueblo Misak se debe a?
        $('#DesercionEscuela').show();
        $('#DesercionEscuela').css('visibility', 'visible');
        $('#ddNoEstudiaResguardoEscuela1').css('display', 'block');


    } else {
        //input ¿Por qué no le gusta que sus hijos estudien en las instituciones educativas del resguardo de Guambia?
        $('#ddNoEstudiaResguardoEscuela :nth-child(0)').prop('selected', true);
        $('#NoGustaQueEstudienGuambia').hide();
        $('#NoGustaQueEstudienGuambia').css('visibility', 'hidden');
        $('#ddNoEstudiaResguardoEscuela').css('display', 'none');
        //input ¿El problema de la deserción escolar    en nuestro pueblo Misak se debe a?
        $('#ddNoEstudiaResguardoEscuela1 :nth-child(0)').prop('selected', true);
        $('#DesercionEscuela').hide();
        $('#DesercionEscuela').css('visibility', 'hidden');
        $('#ddNoEstudiaResguardoEscuela1').css('display', 'none');
    }
};


function showArmonizacion() {
    var e = document.getElementById("ddArmonizacion");
    var strUser = e.options[e.selectedIndex].value;
    if (strUser == 1) {
        //input ¿Hace rituales de armonización y de equilibrio como familia?
        $('#SiHaceArmonizacion').show();
        $('#SiHaceArmonizacion').css('visibility', 'visible');
        $('#ddSiHaceArmonizacion').css('display', 'block');

    } else {
        //input *Cada cuanto se hace a la armonizació
        $('#ddSiHaceArmonizacion :nth-child(1)').prop('selected', true);
        $('#SiHaceArmonizacion').hide();
        $('#SiHaceArmonizacion').css('visibility', 'hidden');
        $('#ddSiHaceArmonizacion').css('display', 'none');

    }
};
</script>




<script>
function pageLoad() {
    //--Modificación para disminuir lentitud de la página y disminuir las peticiones al servidor.

    showNoEstudiaResguardo();

}
</script>


<script type="text/javascript">
$('#Hogar').submit(function(e) {
    e.preventDefault(); //cancelar el envio
    var url = $("#Hogar").attr('action');
    var type = $("#Hogar").attr('method');
    $.ajax({
        type: type,
        url: base + '/' + url,
        data: $('#Hogar').serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.validate) {
                Swal.fire(
                    'Exito',
                    'Se ha guardado con éxito ss',
                    'success'
                )
                setTimeout(function() {
                    location.href = base + "/Ingresar_personas/" + response.id;
                }, 2000);

            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Se generó un error al guardar!',
                })
            }
        }
    })
})
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan Marulanda\Desktop\sipemp-version_1\resources\views/interfaces/hogar.blade.php ENDPATH**/ ?>