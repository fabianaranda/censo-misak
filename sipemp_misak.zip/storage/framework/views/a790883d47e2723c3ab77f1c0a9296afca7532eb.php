<?php $__env->startSection('content'); ?>

<style>
    .enlace {
        display: inline;
        border: 0;
        padding: 0;
        margin: 0;
        text-decoration: underline;
        background: none;
        color: #000088;
        font-family: arial, sans-serif;
        font-size: 1em;
        line-height: 1em;
    }

    .enlace:hover {
        text-decoration: none;
        color: #0000cc;
        cursor: pointer;
    }

</style>

<!--\\\\\\\ contentpanel start\\\\\\-->
<div class="pull-left breadcrumb_admin clear_both">
    <div class="pull-left page_title theme_color">
        <h1>Validacion</h1>
        <h2 class="">Retiro Persona del Censo Poblacional</h2>
    </div>
    <div class="pull-right">
        <ol class="breadcrumb">
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Retiro censo Poblacioanal</a></li>
            <li class="active">Validacion</li>
        </ol>
    </div>
</div>


<div class="container">
    <!-- Fin Informacion menu izquierda-->
    <div style="margin-bottom: 2em;" class="col-md-12">
        <div class="ContenedorFormularioCenso">
            <div class="color_infor noPrint" style="margin-top: 15px;">
                <span class="color_infor  noPrint">Usted se encuentra en:&nbsp;&nbsp;Validación &gt; <font
                        color="#666666"> Personas que se retiraran del censo poblacional Misak </font></span>
            </div>
            <div class="block-web full" style="overflow-y: auto; height: 500px;">
                <ul class="nav nav-tabs nav-justified nav_bg">
                    <li class="active"><a href="#Informacion_del_sistema" data-toggle="tab"><i
                                class="fa fa-laptop"></i>Persona que van a ser retirado del sistema de información
                            Poblacional SIPEMP </a></li>
                </ul>
                <table class="table table-striped table-bordered table-hover" id="solicitudes">
                    <thead>
                        <tr>
                            <th>Documento</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Tipo novedad</th>
                            <th>Motivo</th>
                            <th>Acta</th>
                            <th>Fecha de retiro</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $novedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($novedad->docomento_persona); ?></td>
                                <td><?php echo e($novedad->nombres); ?></td>
                                <td><?php echo e($novedad->apellidos); ?></td>
                                <td><?php echo e($novedad->tipo_novedad==0?'Fallecimiento':'retiro'); ?>

                                </td>
                                <td><?php echo e($novedad->motivo_retiro); ?></td>
                                <td><button class="enlace" onclick="decargarActa(<?php echo e($novedad->id); ?>);">Descargar
                                        acta</button></td>
                                <td><?php echo e($novedad->fecha_retiro); ?></td>
                                <td><?php echo e($novedad->estado==0?'No autorizada':'Autorizada'); ?>

                                </td>
                                <td><button class="enlace"
                                        onclick="cambiarEstado(<?php echo e($novedad->id); ?>);"><?php echo e($novedad->estado==0?'Autorizar':'Desautorizar'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            <!--FIN ContenedorFormularioCenso-->
        </div>
        <!--FIN col-md-9-->
    </div>
</div>
<div id="ConfirmAction" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title">Confirmar Acción</h5>
            </div>
            <div class="modal-body">
                <p>¿Esta seguro que desea realizar esta acción?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="btnConfirmar">Confirmar</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    let id_novedadForm = 0;
    let modalConfirm = $('#ConfirmAction');
    $(document).ready(() => {

        $('#btnConfirmar').click((e) => {
            e.preventDefault();
            $.ajax({
                type: 'GET',
                url: '/cambiar-estado-solicitud/' + id_novedadForm,
                dataType: 'json',
                contentType: false,
                processData: false,
                success: (response) => {
                    if (response.result) {

                        Swal.fire('Exito', 'Se ha guardado con éxito.', 'success');

                        setTimeout(function () {
                            location.href = '/Validacion';
                        }, 2000);
                    } else {

                        Swal.fire('Error',
                            'Se genero un problema, comuniquese con el administrador.',
                            'error');

                    }
                },
            }).always(() => {
                modalConfirm.modal('hide');
            });
        });

    });

    function decargarActa(id_novedad) {
        $.ajax({
            type: 'GET',
            url: '/descargar-acta/' + id_novedad,
            dataType: 'json',
            contentType: false,
            processData: false,
        }).done((response) => {
            if (response.result) {

                var a = document.createElement("a");
                a.href = 'data:application/pdf;base64,' + response.pdf;
                a.download = "acta.pdf"; //update for filename
                a.target = '_blank';
                document.body.appendChild(a);
                a.click();

            } else {

                Swal.fire('Error',
                    'Se genero un problema, comuniquese con el administrador.',
                    'error');

            }

        });
    }

    function cambiarEstado(id_novedad) {
        id_novedadForm = id_novedad;
        modalConfirm.modal('show');
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan Marulanda\Desktop\sipemp-version_1\resources\views//novedad_retiro/validacion_retiro.blade.php ENDPATH**/ ?>