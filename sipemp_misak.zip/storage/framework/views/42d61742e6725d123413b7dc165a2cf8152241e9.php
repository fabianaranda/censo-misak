<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="css/estilos_pie_pagina.css">
<div class="pull-left breadcrumb_admin clear_both">
        <div class="pull-left page_title theme_color">
          <h1><?php echo app('translator')->getFromJson('PERFIL'); ?></h1> 
          <h2 class=""></h2>
        </div>
        <div class="pull-right">
          <ol class="breadcrumb">
            <li><a href="#"><?php echo app('translator')->getFromJson('Inicio'); ?></a></li>
           
            <li class="active"> <?php echo app('translator')->getFromJson('Perfil'); ?></li>
          </ol>
        </div>
      </div>

  <!--\\\\\\\left_nav end \\\\\\-->
  


  <!--\\\\\\\ container  start \\\\\\-->
  <div class="page-content" background="">

  
          <div class="row">
            <div class="col-md-4">
              
              <div class="profile_bg"  >
                <div class="user-profile-sidebar">
                  <div class="row">
                    <div class="col-md-4"><img style="width:80px" src="images/images.png" /></div>
                    <div class="col-md-8">
                      <div class="user-identity">
                        <h4><strong><?php echo e(Auth::user()->name); ?></strong></h4>
                        <p><i class="fa fa-map-marker"></i> <?php echo e(Auth::user()->apellidos); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="account-status-data">
                  <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12">
					  <div class="col-md-12">
					  
					   <div class="input-group-sm">
                           <label ></span>Cargo en el Cabildo</label>
                           <div class="mover_input">
                        <input name="id" type="text" value="<?php echo e(Auth::user()->cargo); ?>"  tabindex="2" class="form-control" style="width : 200px;" autocomplete="on"  value="" align="center"  disabled  >
                        </div>
         
                        </div>
                        <style>
                        .mover_input{
                          margin-left:80px;
                        }
                        </style>
					         </div>
                     </div>
                 </div>
                </div>
                <div class="user-button">
                <div class="row">
                   <!-- <div class="col-sm-6">
                      <button type="button" class=" btn btn-primary btn-rounded"><i class="fa fa-envelope"></i>Normas del sistema</button>
                    </div>
                    <div class="col-sm-6">
                      <button type="button" class="btn btn-primary btn-rounded"><i class="fa fa-user"></i>Manual de Usuario </button>
                    </div>-->
                  </div>
                </div>
           

              </div>
          
              
             
            </div>
            <!--/col-md-4-->
            <div class="col-md-8">
              <div class="block-web full">
                <ul class="nav nav-tabs nav-justified nav_bg">
                  <li class="active"><a href="#about" data-toggle="tab"><i class="fa fa-user"></i><?php echo app('translator')->getFromJson('Información'); ?></a></li>
                  
                </ul>
                <div class="ContenedorFormularioCenso">
                <div class="tab-content ContenedorFormularioCenso">
                  <div class="tab-pane animated fadeInRight active" id="about">
                    <div class="user-profile-content">
                    
                      <hr>
                      <div class="row">
                        <div class="col-sm-6">
                          <h5><strong> <?php echo app('translator')->getFromJson('CONTACTO -USUARIO'); ?> </h5>
                          <address>
                          <strong> <?php echo app('translator')->getFromJson('Telefono'); ?></strong><br>
                          <abbr title="Phone">354 123 4567</abbr>
                          </address>
                          <address>
                          <strong>Correo electrónico</strong><br>
                          <a ><?php echo e(Auth::user()->email); ?></a>
                          </address>
                          <address>
                          <strong></strong><br>
                          <a href=""></a>
                          </address>
                        </div>
                        <div class="col-sm-6">
                         
                          <p></p>
                          <p></p>
                          <div class="user-button">
                <div class="row">
                   <div class="col-sm-6">
                      <button type="button" class=" btn btn-primary btn-rounded"><i class="fa fa-envelope"></i>Normas del sistema</button>
                    </div>
                    <div class="col-sm-6">
                      <button type="button" class="btn btn-primary btn-rounded"><i class="fa fa-user"></i>Manual de Usuario </button>
                    </div>
                  </div>
                </div>
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                  </div>
     
          
           
                </div>
                <!--/tab-content-->
              </div>
              <!--/block-web-->
            </div>
            <!--/col-md-8-->
          </div>
          <!--/row-->
        </div>
      </div>
      <!--\\\\\\\ container  end \\\\\\-->
    </div>
    <!--\\\\\\\ content panel end \\\\\\-->
  </div>
  <!--\\\\\\\ inner end\\\\\\-->
</div>
<!--\\\\\\\ wrapper end\\\\\\-->


<?php $__env->stopSection(); ?>
  



<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipemp_misak\resources\views/home.blade.php ENDPATH**/ ?>