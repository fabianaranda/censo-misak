<?php
 return [
'es'=>['Spanish','es_ES'],
'en'=>['Enquish','en_En'],
'na'=>['Misak','na_NA'],
];