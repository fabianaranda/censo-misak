<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class carnet_salud extends Model
{
    public $table = "postres"; 
}
