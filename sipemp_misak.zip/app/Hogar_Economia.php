<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_Economia extends Model
{
    protected $table = "hoga_economia_familia";
    public $timestamps = false;
}
