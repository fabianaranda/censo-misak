<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Novedad_retiro extends Model
{
    public $table='novedades_retiros';
}
