<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class info_persona_idiomas extends Model
{
    public $table = "info_persona_idiomas"; 
    public $timestamps = false;	
}
