<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PermisoUsuario extends Model
{
    public $table='permisos_usuario';
}
