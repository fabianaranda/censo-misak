<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class colegio extends Model
{
    public $table = "colegio"; 
}
