<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_plantasNutricional extends Model
{
    protected $table = "hogar_plantas_nutricionales";
    public $timestamps = false;
}
