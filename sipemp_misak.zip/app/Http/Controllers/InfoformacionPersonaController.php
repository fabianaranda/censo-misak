<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\info_persona;
use Illuminate\Support\Facades\DB;

class InfoformacionPersonaController extends Controller
{


}
