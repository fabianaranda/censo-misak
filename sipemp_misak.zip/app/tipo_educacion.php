<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipo_educacion extends Model
{
    public $table = "tipoe"; 
}
