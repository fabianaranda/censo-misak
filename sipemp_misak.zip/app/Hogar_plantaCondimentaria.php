<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_plantaCondimentaria extends Model
{
    protected $table = "hogar_plantas_codimentarias";
    public $timestamps = false;
}
