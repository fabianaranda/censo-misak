<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class municipio extends Model
{
    public $table = "municipiocolegio"; 
}
