<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sede extends Model
{
    public $table = "sede"; 
}
