<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_plantasEspirituales extends Model
{
    protected $table = "hogar_plantas_espirituales";
    public $timestamps = false;
}
