<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_Comida extends Model
{
    protected $table = "hogar_comidas_propias";
    public $timestamps = false;
}
