<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class departamento extends Model
{
    public $table = "departamento_colegio"; 
}
