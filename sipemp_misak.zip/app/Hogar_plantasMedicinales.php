<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_plantasMedicinales extends Model
{
    protected $table = "hogar_plantas_medicinales";
    public $timestamps = false;
}
