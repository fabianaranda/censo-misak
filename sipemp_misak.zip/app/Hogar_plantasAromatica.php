<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hogar_plantasAromatica extends Model
{
    protected $table = "hogar_plantasaromaticas";
    public $timestamps = false;

}
