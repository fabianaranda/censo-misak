<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class limitaciones_fisinas extends Model
{

        public $timestamps = false;	
        public $table = "limitaciones_fisinas"; 
         
    
        /**
         * The attributes that are mass assignable.
         *
         * @var array
         */
        
         protected $fillable = [
             'nombre',
        ];
    
}
