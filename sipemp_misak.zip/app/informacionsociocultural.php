<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class informacionsociocultural extends Model
{
    //
}
