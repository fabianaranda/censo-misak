<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class info_persona_limitaciones extends Model
{
    public $table = "info_persona_limitaciones";
    public $timestamps = false;	
}
