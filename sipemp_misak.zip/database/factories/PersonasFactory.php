<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\personas;
use Faker\Generator as Faker;

$factory->define(personas::class, function (Faker $faker) {
    return [
        //
    ];
});
